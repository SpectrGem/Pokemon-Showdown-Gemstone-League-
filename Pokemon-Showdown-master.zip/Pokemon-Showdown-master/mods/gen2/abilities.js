/**
 * Gen 2 had no abilities whatsoever.
 */

'use strict';

exports.BattleAbilities = {
	"None": {
		desc: "This Pokemon has no ability.",
		shortDesc: "This Pokemon has no ability.",
		id: "none",
		name: "None",
		rating: 1,
		num: 1,
	},
};
